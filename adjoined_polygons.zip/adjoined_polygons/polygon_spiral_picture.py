


import matplotlib.pyplot as plt
import pandas as pd
import math
import numpy as np
import pylab

def create_polygon(n):
    polygon = pd.DataFrame({'x':[],'y':[]})
    point_angle = (360 / n) * (math.pi / 180)
    side = math.sin(((n - 2) * math.pi)/(2 * n)) / math.sin((2 * math.pi)/(n))
    for i in range(0,n,1):
        if ((n % 4) == 0):
            rotation_angle = point_angle / 2
        elif ((n % 2) == 0):
            rotation_angle = 0
        else:
            rotation_angle = math.pi / 2
        point = {'x':side * math.cos((i * point_angle) + rotation_angle),
                 'y':side * math.sin((i * point_angle) + rotation_angle)}
        polygon = polygon.append(point, ignore_index = True)

    low_point = polygon.copy()
    low_point = low_point.sort_values(by = ['y'], ascending = True)
    low_point = low_point.head(2)
    low_point = low_point.reset_index(drop = True)
    low_point = low_point.sort_values(by = ['x'], ascending=True)
    low_point = low_point.head(1)
    low_point = low_point.reset_index(drop = True)
    low_x = low_point.loc[0,'x']
    low_y = low_point.loc[0,'y']
    polygon['x'] = polygon['x'] - low_x
    polygon['y'] = polygon['y'] - low_y

    polygon['r'] = 0
    for i in range(0,polygon.shape[0],1):
        polygon.loc[i,'r'] = math.sqrt(polygon.loc[i,'x'] ** 2 + polygon.loc[i,'y'] ** 2)

    index_of_first_edge = polygon[polygon['r'] < 1000 * np.finfo(np.float64).eps].index.to_list()[0]
    polygon = polygon[index_of_first_edge:].append(polygon[0:index_of_first_edge])
    polygon = polygon.reset_index(drop = True)
    close_point = {'x': polygon.loc[0, 'x'], 'y': polygon.loc[0, 'y'],'r':polygon.loc[0,'r']}
    polygon = polygon.append(close_point, ignore_index=True)
    return polygon

def rotate_polygon(initial_polygon, terminal_polygon):
    terminal_polygon = terminal_polygon.drop(columns = ['r'])
    initial_edge = initial_polygon[1:3].copy()

    temp_edge = initial_polygon[1:3].copy()
    temp_edge['x'] = initial_edge['x'] - initial_edge.loc[1,'x']
    temp_edge['y'] = initial_edge['y'] - initial_edge.loc[1,'y']

    rise = initial_edge.loc[2,'y'] - initial_edge.loc[1,'y']
    run = initial_edge.loc[2,'x'] - initial_edge.loc[1,'x']
    if (rise > 0 and run == 0):
        rotation_angle = math.pi / 2
    elif (rise < 0 and run == 0):
        rotation_angle = (3 * math.pi) / 2
    elif (rise == 0 and run < 0):
        rotation_angle = math.atan(rise / run) + math.pi
    elif (rise == 0 and run > 0):
        rotation_angle = math.atan(rise / run)
    elif (rise > 0 and run > 0):
        rotation_angle = math.atan(rise / run)
    elif (rise > 0 and run < 0):
        rotation_angle = math.atan(rise / run) + math.pi
    elif (rise < 0 and run < 0):
        rotation_angle = math.atan(rise / run) + math.pi
    elif (rise < 0 and run > 0):
        rotation_angle = math.atan(rise / run)

    temp_polygon = terminal_polygon.copy()
    temp_polygon = temp_polygon[['x','y']].T
    rotation_matrix = temp_edge.copy()
    rotation_matrix = rotation_matrix[['x', 'y']]
    rotation_matrix = rotation_matrix.reset_index(drop = True)
    rotation_matrix.loc[0,'x'] = math.cos(rotation_angle)
    rotation_matrix.loc[0,'y'] = -1 * math.sin(rotation_angle)
    rotation_matrix.loc[1,'x'] = math.sin(rotation_angle)
    rotation_matrix.loc[1,'y'] = math.cos(rotation_angle)
    temp_polygon = pd.DataFrame(rotation_matrix.dot(temp_polygon))
    temp_polygon = temp_polygon.T
    temp_polygon = temp_polygon.rename(columns = {0:'x',1:'y'})
    # terminal_polygon['x_r'] = temp_polygon['x']
    # terminal_polygon['y_r'] = temp_polygon['y']
    terminal_polygon['x'] = temp_polygon['x'] + initial_edge.loc[1,'x']
    terminal_polygon['y'] = temp_polygon['y'] + initial_edge.loc[1,'y']
    return terminal_polygon

p03 = create_polygon(3)
p04 = create_polygon(4)
p05 = create_polygon(5)
p06 = create_polygon(6)
p07 = create_polygon(7)
p08 = create_polygon(8)
p09 = create_polygon(9)
p10 = create_polygon(10)
p11 = create_polygon(11)
p12 = create_polygon(12)
p13 = create_polygon(13)
p14 = create_polygon(14)
p15 = create_polygon(15)
p16 = create_polygon(16)
p17 = create_polygon(17)
p18 = create_polygon(18)

fig = plt.figure(figsize = (6,6))
pylab.fill(list(p18['x']),list(p18['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p17['x']),list(p17['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p16['x']),list(p16['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p15['x']),list(p15['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p14['x']),list(p14['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p13['x']),list(p13['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p12['x']),list(p12['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p11['x']),list(p11['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p10['x']),list(p10['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p09['x']),list(p09['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p08['x']),list(p08['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p07['x']),list(p07['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p06['x']),list(p06['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p05['x']),list(p05['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p04['x']),list(p04['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p03['x']),list(p03['y']), 'white', alpha=1, edgecolor='lightgray')
plt.plot(p03['x'],p03['y'],'k',linewidth = 1)
plt.plot(p04['x'],p04['y'],'k',linewidth = 1)
plt.plot(p05['x'],p05['y'],'k',linewidth = 1)
plt.plot(p06['x'],p06['y'],'k',linewidth = 1)
plt.plot(p07['x'],p07['y'],'k',linewidth = 1)
plt.plot(p08['x'],p08['y'],'k',linewidth = 1)
plt.plot(p09['x'],p09['y'],'k',linewidth = 1)
plt.plot(p10['x'],p10['y'],'k',linewidth = 1)
plt.plot(p11['x'],p11['y'],'k',linewidth = 1)
plt.plot(p12['x'],p12['y'],'k',linewidth = 1)
plt.plot(p13['x'],p13['y'],'k',linewidth = 1)
plt.plot(p14['x'],p14['y'],'k',linewidth = 1)
plt.plot(p15['x'],p15['y'],'k',linewidth = 1)
plt.plot(p16['x'],p16['y'],'k',linewidth = 1)
plt.plot(p17['x'],p17['y'],'k',linewidth = 1)
plt.plot(p18['x'],p18['y'],'k',linewidth = 1)
plt.gca().spines["top"].set_visible(False)
plt.gca().spines["right"].set_visible(False)
plt.gca().spines["bottom"].set_visible(False)
plt.gca().spines["left"].set_visible(False)
plt.axis('off')
fig.savefig('spiral.png', dpi = 600)
# plt.show()
plt.close()

p05 = rotate_polygon(p04,p05)
p06 = rotate_polygon(p05,p06)
p07 = rotate_polygon(p06,p07)
p08 = rotate_polygon(p07,p08)
p09 = rotate_polygon(p08,p09)
p10 = rotate_polygon(p09,p10)
p11 = rotate_polygon(p10,p11)
p12 = rotate_polygon(p11,p12)
p13 = rotate_polygon(p12,p13)
p14 = rotate_polygon(p13,p14)
p15 = rotate_polygon(p14,p15)
p16 = rotate_polygon(p15,p16)
p17 = rotate_polygon(p16,p17)
p18 = rotate_polygon(p17,p18)

fig = plt.figure(figsize = (6,6))
pylab.fill(list(p18['x']),list(p18['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p17['x']),list(p17['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p16['x']),list(p16['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p15['x']),list(p15['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p14['x']),list(p14['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p13['x']),list(p13['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p12['x']),list(p12['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p11['x']),list(p11['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p10['x']),list(p10['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p09['x']),list(p09['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p08['x']),list(p08['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p07['x']),list(p07['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p06['x']),list(p06['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p05['x']),list(p05['y']), 'white', alpha=1, edgecolor='lightgray')
pylab.fill(list(p04['x']),list(p04['y']), 'g', alpha=0.2, edgecolor='r')
pylab.fill(list(p03['x']),list(p03['y']), 'white', alpha=1, edgecolor='lightgray')
plt.plot(p03['x'],p03['y'],'k',linewidth = 1)
plt.plot(p04['x'],p04['y'],'k',linewidth = 1)
plt.plot(p05['x'],p05['y'],'k',linewidth = 1)
plt.plot(p06['x'],p06['y'],'k',linewidth = 1)
plt.plot(p07['x'],p07['y'],'k',linewidth = 1)
plt.plot(p08['x'],p08['y'],'k',linewidth = 1)
plt.plot(p09['x'],p09['y'],'k',linewidth = 1)
plt.plot(p10['x'],p10['y'],'k',linewidth = 1)
plt.plot(p11['x'],p11['y'],'k',linewidth = 1)
plt.plot(p12['x'],p12['y'],'k',linewidth = 1)
plt.plot(p13['x'],p13['y'],'k',linewidth = 1)
plt.plot(p14['x'],p14['y'],'k',linewidth = 1)
plt.plot(p15['x'],p15['y'],'k',linewidth = 1)
plt.plot(p16['x'],p16['y'],'k',linewidth = 1)
plt.plot(p17['x'],p17['y'],'k',linewidth = 1)
plt.plot(p18['x'],p18['y'],'k',linewidth = 1)
plt.gca().spines["top"].set_visible(False)
plt.gca().spines["right"].set_visible(False)
plt.gca().spines["bottom"].set_visible(False)
plt.gca().spines["left"].set_visible(False)
plt.axis('off')
fig.savefig('spiral_rotated.png', dpi = 600)
# plt.show()
plt.close()

